package com.example.thenewsapp.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.thenewsapp.LoginActivity
import com.example.thenewsapp.R
import com.example.thenewsapp.SharedPreferenceManager
import com.example.thenewsapp.databinding.FragmentSettingsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth

/**
 * A simple [Fragment] subclass.
 * Use the [settingsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class settingsFragment : Fragment(R.layout.fragment_settings) {
    lateinit var binding: FragmentSettingsBinding
    lateinit var user: FirebaseAuth
    private val themeTitlelist = arrayOf("Light","Dark","Auto (System Default)")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentSettingsBinding.bind(view)
        user = FirebaseAuth.getInstance()

        // Initialize changeThemeBtn and themeText
        val changeThemeBtn = view.findViewById<Button>(R.id.changeThemeBtn)
        val themeText = view.findViewById<TextView>(R.id.themetext)
        val sharedPreferenceManager = SharedPreferenceManager(requireContext())
        var checkedTheme = sharedPreferenceManager.theme
        themeText.text = "Theme: ${themeTitlelist[sharedPreferenceManager.theme]}"

        // Set click listener for changeThemeBtn
        changeThemeBtn.setOnClickListener {
            val themeDialog = MaterialAlertDialogBuilder(requireContext())
                .setTitle("Theme")
                .setPositiveButton("OK") { _, _ ->
                    sharedPreferenceManager.theme = checkedTheme
                    themeText.text = "Theme: ${themeTitlelist[sharedPreferenceManager.theme]}"
                }
                .setSingleChoiceItems(themeTitlelist, checkedTheme) { _, which ->
                    checkedTheme = which
                }
                .setCancelable(false)
                .show()
        }

        binding.logoutButton.setOnClickListener {
            user.signOut()
            val loginIntent = Intent(requireContext(), LoginActivity::class.java)
            requireContext().startActivity(loginIntent)
            // Optional: Close the current activity if needed
            // finish()
        }
    }
}

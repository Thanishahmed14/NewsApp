package com.example.thenewsapp

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class MyApp: Application() {

    override fun onCreate() {
        super.onCreate()
        val SharedPreferenceManager = SharedPreferenceManager(this)
        AppCompatDelegate.setDefaultNightMode(SharedPreferenceManager.themeFlag[SharedPreferenceManager.theme])
    }
}
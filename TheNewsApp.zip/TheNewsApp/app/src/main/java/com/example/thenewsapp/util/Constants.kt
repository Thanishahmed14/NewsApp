package com.example.thenewsapp.util

class Constants {
    companion object{
    const val API_KEY = "a83c78216e6d4a03befb69421dd81c87"
    const val BASE_URL = "https://newsapi.org/"
    const val SEARCH_NEWS_TIME_DELAY = 500L
    const val QUERY_PAGE_SIZE = 20
    }
}